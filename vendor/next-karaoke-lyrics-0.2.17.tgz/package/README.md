# @next-karaoke/lyrics

The package owns the Canvas component/controller, the cached karaoke painter, CPU-tier
slots and DPR, FPS/visibility handling, full and streaming lyrics, PNG sprite URLs, GIF
worker/decoder, asset leases, and authoring/draft preview layouts.

Consumers install a version and import `LyricsCanvas` from `@next-karaoke/lyrics/react`.
They pass their song/timer signals, options, font, and optional layout callback. The authoring
app passes its processed timeline or draft blocks plus its project storage scope. App-specific
UI, storage and audio engines remain in the apps.

```tsx
import { LyricsCanvas } from '@next-karaoke/lyrics/react';

<LyricsCanvas
  musicSignal={player.musicUpdated}
  timerSignal={player.timerUpdated}
  secondsSignal={player.secondsUpdated}
  lyricsSignal={player.lyricsUpdated}
  targetFps={30}
/>
```

There is no public PNG folder to maintain, asset-copy script, sync command, GIF decoder
installation or Canvas loop in the consuming app. Literal `new URL(..., import.meta.url)`
and worker imports let the app bundler publish package assets. Only selected images load.
The GIF decoder is included in the worker. Uploaded images use the host's blob provider;
embedded playback blobs and their lifetime are handled by package scopes.

Use `npm install`, `npm run build`, `npm test` in this repository. `npm run dev` watches source.
For a release, bump the version then run
`node scripts/release-local.mjs ../next-lyr ../karaoke-web-online`. Both apps receive the same
versioned tarball. Install with each app's existing manager: npm in next-lyr, pnpm in karaoke.
Run their checks/builds and commit the dependency, tarball and lockfile. Released artifacts
are immutable. A Git dependency pinned to a release can replace the local tarballs later.

Built-in effect IDs/library version 1 remain stable. New playback files refer to these IDs;
uploaded images remain embedded once per ID. Explicit legacy sprite payloads remain supported.
Original approved PNG assets are retained byte-for-byte. The previous fire artwork is kept
under assets/archive for reference and is not included in the installed runtime.

Visible text and images are independent of recorded cues. Blocks with no timestamp remain
visible and unsung after content moves or effects are removed. They consume no timing units;
entire untimed rows never replace a recorded playback cue. Editor checkboxes restore only
explicit user selections; following a group through history requires `followGroup: true`.

Images are decorative blocks: even legacy image timestamps never enter the cue clock,
lyric progress, or sung units. Playback XML and YKR omit image timestamps. Images retain
their inline position and shared asset ID; surrounding text supplies the line cue.
