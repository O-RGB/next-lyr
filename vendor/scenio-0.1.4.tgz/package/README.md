# Scenio

Song-clock-driven wallpaper rendering, independent of Lyrio and audio engines.
Version 1 supports still WebP images, ordered cues and linear crossfades only.

Use scenio/core for pure validation/evaluation, scenio/runtime for an imperative
DOM player, scenio/react for ScenioView, and scenio/format for portable entries.
The host supplies its compensated clock and an abortable Blob resolver, and owns
storage, image conversion and the song container. No remote URLs, scripts, audio
engine or WASM decoder are loaded from a scene document.

Build with npm install and npm run build; run npm test. Pack immutable archives
with npm pack and install the same version in both consuming apps.
