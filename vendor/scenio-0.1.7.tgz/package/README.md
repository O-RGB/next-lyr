# Scenio

Song-clock-driven wallpaper rendering, independent of Lyrio and audio engines.
Version 1 supports still WebP images, ordered cues and linear crossfades and independent zoom-in/zoom-out.

Use scenio/core for pure validation/evaluation, scenio/runtime for an imperative
DOM player, scenio/react for ScenioView, and scenio/format for portable entries.
The host supplies its compensated clock and an abortable Blob resolver, and owns
storage, image conversion and the song container. No remote URLs, scripts, audio
engine or WASM decoder are loaded from a scene document.

Build with npm install and npm run build; run npm test. Pack immutable archives
with npm pack and install the same version in both consuming apps.

The runtime composites fade and independent zoom using the host song clock. Wrap sparse transport snapshots in `createSmoothClock` (supply the host playback rate), and pass `targetFps` as a number or live getter. Positive values cap rendering; zero follows display refresh, matching the player’s unlimited setting. Clock extrapolation is bounded to 250 ms if host updates stall. Pauses and seeks re-anchor; static scenes do not keep an animation loop running.

Memory policy: retain at most two decoded wallpaper assets (current/outgoing, or current/next) and one compressed prefetch during a fade. Reuse decoded image elements, write compositor styles only when changed, and release object URLs, decoders and timers when hidden, offscreen or disposed. The browser controls its own internal caches/GPU reclamation. Metadata stays in memory; images stay as sliced compressed Blobs until needed.

Use `openMidiWallpaper` / `openBundle` for bounded index-only playback reads. Payload integrity is checked by the runtime immediately before decode. Authoring import should use the strict `readMidiWallpaper` / `readBundle` APIs, which verify every image before storage. Malformed indexes fail immediately; a corrupted optional image falls back to the host background while audio keeps playing.
